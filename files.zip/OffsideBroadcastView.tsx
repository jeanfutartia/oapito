import type { OffsideData } from '../types/types';
import { makeCamera, project, toPoints } from '../lib/camera';
import type { Vec3 } from '../lib/camera';
import { PlayerFigure } from './PlayerFigure';

const W = 740;
const H = 330;
// Câmera lateral elevada, olhando para a linha defensiva. Linhas paralelas à linha de fundo
// (eixo Y) apontam para dentro da imagem e convergem para o ponto de fuga.
const CAM = makeCamera([78, -14, 10], [79, 30, 0], 820, W, H);

// altura (m) de cada ponto do corpo, usada no fio de prumo
const Z: Record<string, number> = { Ombro: 1.45, Joelho: 0.5, 'Pé': 0.08, Chuteira: 0.08, 'Mão/Braço': 1.05 };

const STRIPES = Array.from({ length: 9 }, (_, i) => {
  const x0 = 58 + i * 5.5;
  const pts = toPoints(CAM, [[x0, 8, 0], [x0 + 5.5, 8, 0], [x0 + 5.5, 66, 0], [x0, 66, 0]]);
  return { pts, odd: i % 2 === 1 };
});

const PITCH_LINES: [number, number, number, number][] = [
  [105, 0, 105, 68],
  [88.5, 13.84, 88.5, 54.16],
  [88.5, 13.84, 105, 13.84],
  [88.5, 54.16, 105, 54.16],
  [99.5, 24.84, 99.5, 43.16]
];

const seg = (a: Vec3, b: Vec3) => {
  const p = project(CAM, a);
  const q = project(CAM, b);
  return p && q ? { x1: p.x, y1: p.y, x2: q.x, y2: q.y } : null;
};

interface Props {
  o: OffsideData;
  attColor: string;
  defColor: string;
  delta: number; // cm: >0 = atacante à frente da linha
  defX: number;
  attX: number;
  ballX: number;
  ballY: number;
  locked: boolean;
  phase: number;
}

const ATT_Y = 31.5;
const DEF_Y = 29;

export const OffsideBroadcastView = ({ o, attColor, defColor, delta, defX, attX, ballX, ballY, locked, phase }: Props) => {
  const isOffside = delta > 0;
  const deltaTxt = `${delta > 0 ? '+' : ''}${delta.toFixed(1)} cm`;
  const bestAtt = Math.max(...o.attackerParts.filter(p => p.legal).map(p => p.offsetCm));

  const actors = [
    { id: 'passer', x: 62, y: 38, n: o.passerNumber, c: attColor, dir: 1 as const },
    { id: 'o1', x: 80, y: 25, n: 2, c: defColor, dir: -1 as const },
    { id: 'o2', x: 81.5, y: 42, n: 5, c: defColor, dir: -1 as const },
    { id: 'def', x: defX - 0.4, y: DEF_Y, n: o.defenderNumber, c: defColor, dir: -1 as const },
    { id: 'att', x: attX - 0.4, y: ATT_Y, n: o.attackerNumber, c: attColor, dir: 1 as const }
  ]
    .map(a => ({ ...a, p: project(CAM, [a.x, a.y, 0]) }))
    .filter(a => a.p)
    .sort((a, b) => b.p!.depth - a.p!.depth); // mais longe primeiro

  const lineQuad = toPoints(CAM, [[defX, 6, 0], [attX, 6, 0], [attX, 62, 0], [defX, 62, 0]]);
  const defLine = seg([defX, 6, 0], [defX, 62, 0]);
  const attLine = seg([attX, 6, 0], [attX, 62, 0]);

  const marker = (key: string, x: number, y: number, name: string, color: string, strong: boolean, legal = true) => {
    const top = project(CAM, [x, y, Z[name] ?? 0.5]);
    const gnd = project(CAM, [x, y, 0]);
    if (!top || !gnd) return null;
    return (
      <g key={key} opacity={legal ? 1 : 0.45}>
        <line x1={top.x} y1={top.y} x2={gnd.x} y2={gnd.y} stroke={color} strokeWidth={strong ? 1.8 : 1} strokeDasharray="3 2" />
        <ellipse cx={gnd.x} cy={gnd.y} rx={strong ? 6 : 4} ry={strong ? 2.2 : 1.5} fill={color} />
        <circle cx={top.x} cy={top.y} r={strong ? 4.5 : 3} fill={color} stroke="#fff" strokeWidth={1} />
        {strong && (
          <text x={top.x + 8} y={top.y + 3} fontSize={9} fontWeight={700} fill="#fff">{name}</text>
        )}
      </g>
    );
  };

  const t = Math.min(1, Math.max(0, (ballX - 62.4) / (97 - 62.4)));
  const bTop = project(CAM, [ballX, ballY, 0.11 + 2.4 * Math.sin(Math.PI * t)]);
  const bGnd = project(CAM, [ballX, ballY, 0]);

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-[330px]">
      <rect width={W} height={H} fill="#0b1220" />
      {STRIPES.map((s, i) => s.pts && <polygon key={i} points={s.pts} fill={s.odd ? '#1a6a35' : '#14532d'} />)}
      {PITCH_LINES.map(([x1, y1, x2, y2], i) => {
        const l = seg([x1, y1, 0], [x2, y2, 0]);
        return l && <line key={i} {...l} stroke="rgba(255,255,255,0.7)" strokeWidth={1.6} />;
      })}

      {locked && lineQuad && <polygon points={lineQuad} fill={isOffside ? 'rgba(239,68,68,0.38)' : 'rgba(34,197,94,0.32)'} />}
      {locked && defLine && <line {...defLine} stroke="#38bdf8" strokeWidth={3} />}
      {locked && attLine && <line {...attLine} stroke="#ef4444" strokeWidth={3} strokeDasharray="7 3" />}

      {actors.map(a => (
        <PlayerFigure
          key={a.id}
          sx={a.p!.x}
          sy={a.p!.y}
          h={1.85 * a.p!.scale}
          color={a.c}
          number={a.n}
          dir={a.dir}
          phase={phase + a.n}
          highlight={locked && (a.id === 'att' || a.id === 'def')}
        />
      ))}

      {locked &&
        o.defenderParts.map(p => marker(`d-${p.name}`, defX + p.offsetCm / 100, DEF_Y, p.name, '#38bdf8', p.offsetCm === 0))}
      {locked &&
        o.attackerParts.map(p =>
          marker(`a-${p.name}`, attX + (p.offsetCm - bestAtt) / 100, ATT_Y, p.name, p.legal ? '#f87171' : '#94a3b8', p.legal && p.offsetCm === bestAtt, p.legal)
        )}

      {bGnd && bTop && (
        <g>
          <ellipse cx={bGnd.x} cy={bGnd.y} rx={bGnd.scale * 0.14} ry={bGnd.scale * 0.05} fill="rgba(0,0,0,0.4)" />
          <circle cx={bTop.x} cy={bTop.y} r={Math.max(3, bTop.scale * 0.11)} fill="#fff" stroke="#111" strokeWidth={1.2} />
        </g>
      )}

      {locked && (
        <g transform="translate(250 6)">
          <rect width={240} height={34} rx={6} fill="rgba(2,6,23,0.92)" stroke={isOffside ? '#ef4444' : '#22c55e'} strokeWidth={2} />
          <text x={120} y={22} textAnchor="middle" fontSize={15} fontWeight={900} fill={isOffside ? '#f87171' : '#4ade80'}>
            {isOffside ? 'IMPEDIMENTO' : 'POSIÇÃO REGULAR'} • {deltaTxt}
          </text>
        </g>
      )}
      <text x={10} y={H - 8} fontSize={9} fill="#94a3b8">
        Perspectiva real: cada ponto do corpo desce em fio de prumo até o gramado; ombro/joelho/pé contam, mão e braço não.
      </text>
    </svg>
  );
};
