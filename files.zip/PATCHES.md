# O APITO — patches nos arquivos existentes

Os 6 arquivos novos/substituídos (`camera.ts`, `useFrameScrubber.ts`, `OffsideBroadcastView.tsx`, `geminiService.ts`,
`soundEffects.ts`, `career.ts`) são cópia direta. Abaixo, o que alterar no resto. Nada disto foi compilado aqui:
rode `npm run build` depois de cada bloco.

---

## 0. Correções de 1 linha (fazer primeiro)

1. **App.tsx não passa cores nem velocidade ao campo.** Hoje todo jogo é vermelho x branco e o 4x/8x só acelera o relógio:
   ```tsx
   <PitchCanvas
     isPlaying={activeMatch.status === 'PLAYING'}
     isPausedForKmi={activeMatch.status !== 'PLAYING' && activeMatch.status !== 'FINISHED'}
     temperature={activeMatch.matchTemperature}
     homeColor={activeMatch.homeTeam.primaryColor}
     awayColor={activeMatch.awayTeam.primaryColor}
     homeRedCards={activeMatch.homeRedCards}
     awayRedCards={activeMatch.awayRedCards}
     speed={activeMatch.matchSpeed}
   />
   ```
2. **Tailwind via CDN** (`index.html`) não serve para produção e ignora o `@tailwindcss/vite` já instalado.
   - `vite.config.ts`: `import tailwindcss from '@tailwindcss/vite'` e `plugins: [react(), tailwindcss()]`
   - `src/index.css`: primeira linha `@import "tailwindcss";`
   - `index.html`: remover `<script src="https://cdn.tailwindcss.com">`
3. **`SmartRefereeDashboard`**: troque `soundEffects.playWhistle('SHORT')` por `soundEffects.playSpray()` e limpe o timer:
   ```tsx
   const timer = useRef<number>();
   useEffect(() => () => clearTimeout(timer.current), []);
   // em handleUseSpray: timer.current = window.setTimeout(() => {...}, 1000);
   ```

---

## 1. `types/types.ts`

```ts
export interface RefereeProfile {
  // ...campos atuais...
  bankBalance: number;
  weeklyExpenses: number;
  fatigue: number;              // 0..100
  completedCourses: string[];
}

export interface Incident {
  // ...campos atuais...
  neutralBrief?: string;        // texto SEM veredito, usado na UI antes da decisão e no prompt do VAR
}
```

---

## 2. `store/useGameStore.ts`

### 2.1 Imports e estado novo
```ts
import {
  RATING, ratingAfter, SEASON_LENGTH, evaluateSeason, newSeasonState, describeSeason, RECYCLING_COST,
  matchFee, simulateOtherMatches, resetTables, buildStjdCases, judgeCase, addSuspension, tickSuspensions,
  suspendedFor, teamWithAbsences, fatigueAfterMatch, fatigueAfterAction, enrollCourse,
  pressureAfterCall, shouldMobbing, resolveMobbing
} from './career';
import type { SeasonState, StjdCase, Suspension, ReportDetail, MobbingResponse } from './career';

// em GameState:
season: SeasonState;
careerNews: string[];
suspensions: Suspension[];
stjdQueue: StjdCase[];
pressure: number;                       // 0..100 ("clima quente")
mobbing: { minute: number; team: 'HOME' | 'AWAY' } | null;
fileStjdReport: (caseId: string, detail: ReportDetail) => void;
answerMobbing: (r: MobbingResponse) => void;
takeCourse: (id: string) => string | null;
```
Valores iniciais: `season: newSeasonState(), careerNews: [], suspensions: [], stjdQueue: [], pressure: 30, mobbing: null`,
e no `referee` inicial: `bankBalance: 1200, weeklyExpenses: 350, fatigue: 0, completedCourses: []`.

### 2.2 Nota: use as constantes (e base 8.2)
- `matchRating: 8.4` e `uefaScore: 8.4` em `startScheduledMatch` → `RATING.base`
- `applyIncidentDecision`: `clamp(m.matchRating + (isCorrect ? 0.12 : -0.45), 4, 10)` →
  `ratingAfter(m.matchRating, isCorrect ? RATING.correct : RATING.wrong)`
- `resolveManagerIncident`: `0.08 / -0.2` → `RATING.managerOk / RATING.managerWrong`

### 2.3 Tabela: reaproveite `applyScore`
Apague a função local `applyResult` e use `applyScore` de `career.ts` (mesma lógica, exportada).

### 2.4 Desfalques (STJD) ao montar a partida — dentro de `startScheduledMatch`
```ts
const sus = get().suspensions;
const home = teamWithAbsences(schedule.home, suspendedFor(sus, schedule.home.id).length);
const away = teamWithAbsences(schedule.away, suspendedFor(sus, schedule.away.id).length);
const incidents = getRandomIncidentsForMatch(home, away);
// e use home/away em activeMatch.homeTeam / awayTeam
soundEffects.startAmbience();
```

### 2.5 `finishMatch` completo (substitui o atual)
```ts
finishMatch: async () => {
  const s = get();
  const a = s.activeMatch;
  const pm = s.postMatch;
  if (!a || !pm) return;
  const prev = s.referee;
  const rating = pm.uefaScore;
  const matches = prev.stats.matches + 1;
  const avg = (prev.uefaAverageScore * prev.stats.matches + rating) / matches;

  // temporada (só notas da temporada corrente)
  const scores = [...s.season.scores, rating];
  const seasonEnd = scores.length >= SEASON_LENGTH;
  const result = seasonEnd ? evaluateSeason(prev.tier, scores) : null;

  // tabela: os 2 times do jogo + o resto da rodada
  let teams = applyResult(s.teams, a.homeTeam, a.awayTeam, a.homeScore, a.awayScore); // ou applyScore
  teams = simulateOtherMatches(teams, prev.tier, [a.homeTeam.id, a.awayTeam.id]);
  if (seasonEnd) teams = resetTables(teams);

  // STJD
  const cases = buildStjdCases(pm.report, a.homeTeam, a.awayTeam, a.decisionsHistory);

  // dinheiro e desgaste
  const bonus = result?.bonus ?? 0;
  const recycling = result?.verdict === 'RECYCLING' ? RECYCLING_COST : 0;
  const news = result ? [describeSeason(result, s.season.season)] : [];

  set({
    matchHistory: [pm.report, ...s.matchHistory],
    teams,
    suspensions: tickSuspensions(s.suspensions, [a.homeTeam.id, a.awayTeam.id]),
    stjdQueue: [...s.stjdQueue, ...cases],
    season: seasonEnd ? newSeasonState(s.season.season + 1) : { ...s.season, scores },
    careerNews: [...news, ...s.careerNews].slice(0, 5),
    pressure: 30,
    mobbing: null,
    referee: {
      ...prev,
      tier: result?.tier ?? prev.tier,
      uefaAverageScore: Number(avg.toFixed(2)),
      reputation: clamp(prev.reputation + (rating >= 8.35 ? 2 : -2), 0, 100),
      bankBalance: prev.bankBalance + matchFee(prev.tier) + bonus - prev.weeklyExpenses - recycling,
      fatigue: fatigueAfterMatch(prev.fatigue ?? 0, s.liveStats.distanceCoveredKm),
      stats: {
        matches,
        yellowCards: prev.stats.yellowCards + pm.report.cards.filter(c => c.cardType === 'YELLOW').length,
        redCards: prev.stats.redCards + pm.report.cards.filter(c => c.cardType === 'RED').length,
        penalties: prev.stats.penalties + pm.report.goals.filter(g => g.isPenalty).length,
        varInterventions: prev.stats.varInterventions + pm.report.varReviews.length
      }
    },
    week: s.week + 1,
    activeMatch: null,
    postMatch: null,
    isEvaluatingPostMatch: false,
    currentGoalAnimation: null,
    currentManagerIncident: null,
    liveStats: { ...INITIAL_STATS },
    nextMatchSchedule: null
  });
  soundEffects.stopAmbience();
},

fileStjdReport: (caseId, detail) => {
  const s = get();
  const c = s.stjdQueue.find(x => x.id === caseId);
  if (!c) return;
  const ruling = judgeCase(c, detail);
  set({
    stjdQueue: s.stjdQueue.filter(x => x.id !== caseId),
    suspensions: addSuspension(s.suspensions, c, ruling),
    careerNews: [ruling.summary, ...s.careerNews].slice(0, 5),
    referee: { ...s.referee, reputation: clamp(s.referee.reputation + ruling.reputationDelta, 0, 100) }
  });
},

takeCourse: id => {
  const s = get();
  const r = enrollCourse(s.referee.bankBalance, s.referee.attributes, s.referee.completedCourses ?? [], s.actionPoints, id, s.referee.tier);
  if (!r.ok) return r.reason ?? 'Não foi possível se inscrever.';
  set({ actionPoints: r.actionPoints, referee: { ...s.referee, bankBalance: r.bank, attributes: r.attrs, completedCourses: r.done } });
  return null;
},
```
O `isEvaluatingPostMatch` agora é zerado no `finishMatch`; em `finalizeMatch`, no ramo `if (!cur) return;`
troque por `if (!cur) { set({ isEvaluatingPostMatch: false }); return; }` (hoje o indicador pode ficar preso).

### 2.6 Pressão e mobbing — no fim de `resolveIncident`, antes do `set`
```ts
const againstHome = inc.offendingTeam === 'HOME';
const pressure = pressureAfterCall(state.pressure, {
  correct: res.match.decisionsHistory.at(-1)!.isCorrect,
  severe: decision.includes('RED') || decision === 'GOAL_DISALLOWED',
  againstHome
});
const triggerMobbing = !state.mobbing && shouldMobbing(pressure, state.referee.attributes);
// no set: pressure, mobbing: triggerMobbing ? { minute: inc.minute, team: inc.offendingTeam } : state.mobbing
soundEffects.setCrowdIntensity(res.match.matchTemperature / 100);
if (res.goalAnim) soundEffects.goalRoar();
if (decision.includes('RED') || decision === 'GOAL_DISALLOWED') soundEffects.boo();
```
`answerMobbing(r)`: `resolveMobbing(r, attrs)` → aplicar `rating` via `ratingAfter`, `pressure`, `stress`
(`attributes.stressResistance -= stress`), ticker com `text`, e `mobbing: null`.
UI: copie `ManagerIncidentModal.tsx` trocando os 3 botões pelos 4 de `MobbingResponse`.
O relógio já pausa em `currentManagerIncident`; inclua `|| state.mobbing` na mesma guarda de `updateMatchMinute`.

### 2.7 Persistência com versão (evita save quebrado quando o shape muda)
```ts
{
  name: 'o-apito-save',
  version: 2,
  migrate: (p: any) => ({
    ...p,
    referee: { bankBalance: 1200, weeklyExpenses: 350, fatigue: 0, completedCourses: [], ...p?.referee },
    season: p?.season ?? newSeasonState(),
    suspensions: p?.suspensions ?? [],
    stjdQueue: p?.stjdQueue ?? [],
    careerNews: p?.careerNews ?? []
  }),
  partialize: s => ({
    isProfileCreated: s.isProfileCreated, week: s.week, referee: s.referee, teams: s.teams, matchHistory: s.matchHistory,
    season: s.season, suspensions: s.suspensions, stjdQueue: s.stjdQueue, careerNews: s.careerNews
  })
}
```
`resetCareer`: use `useGameStore.persist.clearStorage(); window.location.reload();`.

**Chave do Gemini:** `referee.geminiApiKey` hoje vai para o `localStorage` em texto puro. Para uso pessoal é aceitável;
para publicar, use um proxy serverless gratuito (Cloudflare Workers/Vercel) que guarda a chave no servidor.

### 2.8 Ticker limitado
Em todo `ticker: [novo, ...a.ticker]` aplique `.slice(0, 40)`.

### 2.9 Times Série C e B
Hoje só existem times de Série D e A: ao promover, o sorteio cairia no fallback. Copie as linhas `c1..c3` e `b1..b3`
do helper `mk(...)` que está dentro de `aplicar-melhorias.mjs` para `ALL_TEAMS_DATABASE`.

---

## 3. `App.tsx` — seletores atômicos
`useGameStore()` sem seletor re-renderiza o App inteiro a cada `set` (a 8x, ~8 vezes por segundo).
```tsx
import { useShallow } from 'zustand/react/shallow';

const s = useGameStore(useShallow(st => ({
  isProfileCreated: st.isProfileCreated, week: st.week, referee: st.referee, teams: st.teams,
  matchHistory: st.matchHistory, nextMatchSchedule: st.nextMatchSchedule,
  currentManagerIncident: st.currentManagerIncident, currentGoalAnimation: st.currentGoalAnimation,
  isEvaluatingPostMatch: st.isEvaluatingPostMatch, postMatch: st.postMatch,
  homeManagerEjected: st.homeManagerEjected, awayManagerEjected: st.awayManagerEjected,
  liveStats: st.liveStats, activeMatch: st.activeMatch
})));
const act = useGameStore.getState(); // ações são estáveis: não precisam de subscrição
```
(No Zustand v5, seletor que devolve objeto novo **sem** `useShallow` entra em loop.) Depois, `s.activeMatch`,
`act.startScheduledMatch`, etc. Envolva `MatchStatsSidebar`, `SmartRefereeDashboard` e `EquipmentBar` em `React.memo`.

No painel de lance capital (`KMI_PAUSED`), troque `{activeMatch.currentIncident.description}` por
`{activeMatch.currentIncident.neutralBrief ?? ''}` (a `description` descreve o veredito).

Primeiro clique: `onClick={() => soundEffects.unlock()}` no botão "Entrar em Campo" (autoplay do navegador).
Rádio VAR: em `openVarRadioIntercom` chame `soundEffects.setHeadset(true)`; em `resolveIncident`, `soundEffects.setHeadset(false)`.

---

## 4. `PitchCanvas.tsx`

### 4.1 Camada estática em cache (hoje ~1.750 `fillRect` de torcida + gradiente a cada frame)
Mude a assinatura: `const drawPitch = (g: CanvasRenderingContext2D) => {` e dentro dela troque `ctx.` por `g.`. Depois:
```ts
let layer: HTMLCanvasElement | null = null;
const buildLayer = () => {
  const c = document.createElement('canvas');
  c.width = W * dpr; c.height = H * dpr;
  const g = c.getContext('2d')!;
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  drawPitch(g);
  return c;
};
// em render(): troque drawPitch();
layer ??= buildLayer();
ctx.drawImage(layer, 0, 0, W, H);
```

### 4.2 Passo fixo (a 8x o `dt` virava 0,4 s: a bola atravessava jogadores sem colisão)
```ts
let acc = 0;
const STEP = 1 / 60;
// em render(), no lugar do bloco `if (running) {...}`:
if (running) {
  acc += dt * Math.max(1, pr.speed);
  let n = 0;
  while (acc >= STEP && n++ < 24) { step(STEP); clock += STEP; acc -= STEP; }
}
```

### 4.3 Gols visuais vindos do jogo (hoje o campo "faz gol" 25% das finalizações sem mexer no placar)
- Prop nova: `goalEvent?: { id: string; side: 0 | 1 }` (App: `currentGoalAnimation && { id: \`${currentGoalAnimation.minute}-${currentGoalAnimation.scoringSide}\`, side: currentGoalAnimation.scoringSide === 'HOME' ? 0 : 1 }`).
- Em `step`, no ramo de finalização, apague o `if (Math.random() < 0.25) { kickoff(...) } else {` e deixe só o ramo da defesa do goleiro.
- No início de `step`:
  ```ts
  const ge = propsRef.current.goalEvent;
  if (ge && ge.id !== seenGoal) { seenGoal = ge.id; kickoff(ball, players, ge.side === 0 ? 1 : 0); }
  ```
  (`let seenGoal = '';` ao lado de `let clock = 0;`; inclua `goalEvent` no `propsRef`.)
  Como a animação de gol pausa o relógio, o campo só reinicia quando o overlay abre.

---

## 5. `OffsideAnalysis.tsx`

1. Scrubber: remova os 3 `useState` de `frame/playing/speed` e os 2 `useEffect` de timer; use
   ```tsx
   const sc = useFrameScrubber({ initial: Math.max(0, (incident.offside?.kickFrame ?? 50) - 16) });
   const f = sc.frame;
   ```
   e troque: `setPlaying(false); setFrame(...)` → `sc.step(±1)`; botão play → `sc.toggle()`; velocidade → `sc.setSpeed(s)` / `sc.speed`;
   "sincronizar toque" → `sc.pause(); sc.seek(o.kickFrame)`; range → `onChange={e => { sc.pause(); sc.seek(Number(e.target.value)); }}`.
   Setas ← → e Espaço passam a funcionar.
2. Vista broadcast: apague `pb()` e `renderBroadcast()` e use
   ```tsx
   {angle === 'BROADCAST' && (
     <OffsideBroadcastView o={o} attColor={attColor} defColor={defColor} delta={delta}
       defX={DEF_X} attX={attX} ballX={ballX} ballY={ballY} locked={locked} phase={phase} />
   )}
   ```
3. Regra 11: rótulo `'Ombro'` → `'Ombro'` mantido, mas documente no texto de ajuda que o limite do braço é a **axila**
   (parte de baixo da axila). `'Mão/Braço'` já está como `legal: false`.
4. O botão "Sincronizar toque (auto)" entrega o frame certo. Se quiser dificuldade maior, esconda-o em divisões ≥ Série B.

---

## 6. Neutralidade do VAR e fidelidade IFAB

### 6.1 Vazamentos hoje (todos aparecem **antes** da decisão do jogador)
| Onde | O que vaza |
|---|---|
| `VARModal` — "Critério IFAB" | `ifabExplanation` descreve a resposta (ex.: "puxar sem disputar a bola é pênalti com vermelho") |
| `IncidentFrameVisualizer` — rótulo de contato | `contactLabel`: "Puxão na camisa do #9", "Empurrão do #7…" |
| `App` — painel do lance | `description`: "puxado pela camisa", "sola exposta", "braço" |
| `geminiService` (versão antiga) | fallbacks do rádio: "intensidade excessiva", "recomendação é que você venha ao monitor" |

Correções:
- `VARModal`: mostre `ifabExplanation` **só depois** da decisão (no dossiê pós-jogo, que já usa o texto). Antes, mostre
  `Protocolo: checagem de {categoria}` (ex.: "Checagem de posição", "Checagem da fase de ataque").
- `IncidentFrameVisualizer`: no `nearContact`, troque `scene.contactLabel` por `'Ponto de contato'`; mantenha o rótulo real para o dossiê.
- `incidentsDatabase.ts`: acrescente `brief: (att: Team, def: Team) => string` em cada `Template` e `neutralBrief: tpl.brief(att, def)` no retorno:
  ```ts
  // IMPEDIMENTO_3D (x2): (att) => `Gol do ${att.shortName}. Checagem de posição no momento do passe.`
  // GOL_POLÊMICO:        (att) => `Gol do ${att.shortName}. Checagem da fase de ataque que antecedeu a finalização.`
  // PENALTI_DISPUTA:     (att, def) => `Contato na área entre atacante do ${att.shortName} e defensor do ${def.shortName}.`
  // DOGSO_CHANCE_CLARA:  (att) => `Atacante do ${att.shortName} em direção ao gol. Checagem de contato antes da finalização.`
  // FORCA_EXCESSIVA:     () => `Disputa no meio-campo. Checagem de contato e intensidade.`
  // MAO_VOLUMETRIA:      (att) => `Finalização do ${att.shortName} na área. Checagem de contato da bola com o defensor.`
  ```
- O `geminiService` novo já só envia `neutralBrief` e descarta respostas com vocabulário de veredito.

### 6.2 Lacunas de regra (Lei 12 / protocolo VAR)
1. **"Erro claro e óbvio".** Hoje `isCorrect = acceptableDecisions.includes(decision)`; em lances subjetivos (disputa na área, força
   excessiva) qualquer divergência da "recomendada" vira erro. Acrescente `subjective: boolean` ao `Incident` e inclua a
   `fieldDecision` em `acceptableDecisions` quando `subjective` for verdadeiro (manter a decisão de campo dentro da margem não é erro).
2. **Simulação.** Queda sem infração é **cartão amarelo por simulação** (+ tiro livre indireto). Adicione `'SIMULATION_YELLOW'` a
   `DecisionType`, a `DECISION_LABEL`, ao grupo `PENALTY` do `VARModal`, e em `applyIncidentDecision`:
   `case 'SIMULATION_YELLOW': card('YELLOW')` com o time **atacante** (o simulador), não o `offendingTeam`.
3. **Segundo amarelo.** Não há acúmulo: ao registrar amarelo, se o mesmo `Camisa N` do mesmo time já tem amarelo no `report.cards`,
   registre também um `RED` ("2º amarelo") e incremente `homeRedCards/awayRedCards`.
4. **DOGSO (4 critérios):** distância ao gol, direção da jogada, possibilidade de manter/ganhar a bola, número e posição dos
   defensores. Exiba como checklist no dossiê. Exceções que dão vermelho mesmo com tentativa de jogar a bola: segurar, puxar,
   empurrar, ou sem possibilidade de jogar a bola. O template de puxão (`PENALTY_RED`) está correto.
5. **APP** está correto (falta na origem anula o gol). Falta: falta que também gera cartão na APP pode ser revisada pelo VAR.

---

## 7. Higiene do repositório
- **Apague `aplicar-melhorias.mjs`**: ele sobrescreve `App.tsx` e `useGameStore.ts` por uma versão antiga (v3) que usa campos que
  `types.ts` não tem (`bankBalance`, `GoalAnimationData` sem `variant`…). Rodar quebra o build.
- **Apague `PROJETO_COMPLETO_VALIDACAO.md`** (dump de uma versão anterior, com `AnatomicPlayerFigure`), `export.cjs`, `diagnostico.txt`,
  `tsconfig.app.tsbuildinfo` (adicione ao `.gitignore`) e `src/App.css` (resto do template Vite, não importado).
- `package.json`: `lucide-react` e `use-sound` não são usados; remova.
- `tsconfig.app.json`: `"strict": false` e `noUnused*: false` escondem erros. Ligue `strict` aos poucos
  (o primeiro incômodo será o `ref as unknown as P` em `PitchCanvas`).
- `animate-fade-in` aparece em vários modais mas não existe no Tailwind: ou defina o keyframe no CSS, ou remova a classe.
