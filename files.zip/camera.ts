/**
 * Câmera pinhole mínima (sem dependências).
 * Mundo em metros: X = comprimento do campo (0..105, ataque vai para +X),
 * Y = largura (0..68), Z = altura. A projeção divide por profundidade, então:
 *  - retas paralelas no chão convergem para pontos de fuga no horizonte;
 *  - verticais (fio de prumo) convergem levemente para o nadir.
 */
export type Vec3 = [number, number, number];

export interface Camera {
  pos: Vec3;
  r: Vec3; // direita
  u: Vec3; // cima
  f: Vec3; // frente
  focal: number; // px
  cx: number;
  cy: number;
}

export interface Projected {
  x: number;
  y: number;
  depth: number; // metros ao longo do eixo óptico
  scale: number; // px por metro nessa profundidade
}

const sub = (a: Vec3, b: Vec3): Vec3 => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const dot = (a: Vec3, b: Vec3) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a: Vec3, b: Vec3): Vec3 => [
  a[1] * b[2] - a[2] * b[1],
  a[2] * b[0] - a[0] * b[2],
  a[0] * b[1] - a[1] * b[0]
];
const norm = (a: Vec3): Vec3 => {
  const l = Math.hypot(a[0], a[1], a[2]) || 1;
  return [a[0] / l, a[1] / l, a[2] / l];
};

export function makeCamera(pos: Vec3, target: Vec3, focalPx: number, width: number, height: number): Camera {
  const f = norm(sub(target, pos));
  const r = norm(cross(f, [0, 0, 1]));
  const u = cross(r, f);
  return { pos, r, u, f, focal: focalPx, cx: width / 2, cy: height / 2 };
}

export function project(c: Camera, p: Vec3): Projected | null {
  const d = sub(p, c.pos);
  const z = dot(d, c.f);
  if (z < 0.5) return null; // atrás (ou colado) na câmera
  const k = c.focal / z;
  return { x: c.cx + dot(d, c.r) * k, y: c.cy - dot(d, c.u) * k, depth: z, scale: k };
}

/** "x,y x,y ..." para <polygon>/<polyline>; null se algum ponto estiver atrás da câmera. */
export function toPoints(c: Camera, pts: Vec3[]): string | null {
  const out: string[] = [];
  for (const p of pts) {
    const q = project(c, p);
    if (!q) return null;
    out.push(`${q.x.toFixed(1)},${q.y.toFixed(1)}`);
  }
  return out.join(' ');
}
