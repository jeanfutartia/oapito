import type { DivisionTier, MatchReport, RefereeAttributes, Team } from '../types/types';

/**
 * Regras de carreira como FUNÇÕES PURAS (sem Zustand, sem Math.random escondido: o rnd é injetável).
 * Isso torna temporada, STJD e pressão testáveis e elimina estado residual entre temporadas.
 */

export const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));
const round2 = (v: number) => Math.round(v * 100) / 100;

/* --------------------------------- nota da partida --------------------------------- */

// Base 8.2: com acertos perfeitos a nota passa de 9.0 (no código atual, 8.4 + 0.12 x 3 nunca chega lá).
export const RATING = {
  base: 8.2,
  correct: 0.25,
  wrong: -0.7,
  managerOk: 0.1,
  managerWrong: -0.3,
  quickOk: 0.1,
  quickNear: -0.12,
  quickWrong: -0.45,
  min: 5,
  max: 10
} as const;

export const ratingAfter = (current: number, delta: number) => clamp(current + delta, RATING.min, RATING.max);

/* ------------------------------------- temporada ------------------------------------ */

export const PLAYABLE_TIERS: DivisionTier[] = ['SERIE_D', 'SERIE_C', 'SERIE_B', 'SERIE_A'];
export const SEASON_LENGTH = 6;
export const PROMOTION_AVG = 9.0;
export const RELEGATION_AVG = 7.0;

export interface SeasonState {
  season: number;
  scores: number[]; // notas SÓ da temporada corrente (não reaproveita matchHistory)
}
export const newSeasonState = (season = 1): SeasonState => ({ season, scores: [] });

export type SeasonVerdict = 'PROMOTED' | 'RELEGATED' | 'RECYCLING' | 'STAY';
export interface SeasonResult {
  verdict: SeasonVerdict;
  tier: DivisionTier;
  avg: number;
  bonus: number;
}

export function evaluateSeason(tier: DivisionTier, scores: number[]): SeasonResult {
  const avg = scores.length ? round2(scores.reduce((a, b) => a + b, 0) / scores.length) : 0;
  const i = PLAYABLE_TIERS.indexOf(tier);
  if (avg > PROMOTION_AVG && i >= 0 && i < PLAYABLE_TIERS.length - 1) {
    return { verdict: 'PROMOTED', tier: PLAYABLE_TIERS[i + 1], avg, bonus: 2500 };
  }
  if (avg < RELEGATION_AVG) {
    // no fundo da pirâmide não há para onde cair: vira "reciclagem" (curso obrigatório)
    return i > 0
      ? { verdict: 'RELEGATED', tier: PLAYABLE_TIERS[i - 1], avg, bonus: 0 }
      : { verdict: 'RECYCLING', tier, avg, bonus: 0 };
  }
  return { verdict: 'STAY', tier, avg, bonus: 1200 };
}

export const RECYCLING_COST = 1500;

export function describeSeason(r: SeasonResult, season: number): string {
  const t = r.tier.replace('_', ' ');
  const head = `Fim da temporada ${season}. Média ${r.avg.toFixed(2)}.`;
  if (r.verdict === 'PROMOTED') return `${head} PROMOÇÃO: você sobe para a ${t}!`;
  if (r.verdict === 'RELEGATED') return `${head} REBAIXAMENTO: você volta para a ${t}.`;
  if (r.verdict === 'RECYCLING') return `${head} Reciclagem obrigatória (R$ ${RECYCLING_COST.toLocaleString()}) e semana de descanso forçado.`;
  return `${head} Você se mantém na ${t} e recebe bônus de permanência.`;
}

const MATCH_FEE: Record<DivisionTier, number> = {
  SERIE_D: 800,
  SERIE_C: 1500,
  SERIE_B: 3000,
  SERIE_A: 6000,
  FIFA_INTERNACIONAL: 12000
};
export const matchFee = (tier: DivisionTier) => MATCH_FEE[tier] ?? 800;

/* ------------------------------ tabela: resto da rodada ------------------------------ */

export function applyScore(t: Team, gf: number, ga: number): Team {
  return {
    ...t,
    played: t.played + 1,
    won: t.won + (gf > ga ? 1 : 0),
    drawn: t.drawn + (gf === ga ? 1 : 0),
    lost: t.lost + (gf < ga ? 1 : 0),
    goalsFor: t.goalsFor + gf,
    goalsAgainst: t.goalsAgainst + ga,
    points: t.points + (gf > ga ? 3 : gf === ga ? 1 : 0)
  };
}

const poisson = (lambda: number, rnd: () => number) => {
  const L = Math.exp(-lambda);
  let k = 0;
  let p = 1;
  do {
    k++;
    p *= rnd();
  } while (p > L);
  return k - 1;
};

/** Hoje só 2 times pontuam por rodada (tabela falsa). Isto joga o resto da divisão. */
export function simulateOtherMatches(teams: Team[], tier: DivisionTier, excludeIds: string[], rnd = Math.random): Team[] {
  const pool = teams.filter(t => t.tier === tier && !excludeIds.includes(t.id)).sort(() => rnd() - 0.5);
  const result = new Map<string, Team>();
  for (let i = 0; i + 1 < pool.length; i += 2) {
    const h = pool[i];
    const a = pool[i + 1];
    const lam = (att: number, def: number, k: number) => Math.max(0.2, 1.25 * (att / def) ** 2 * k);
    const hg = poisson(lam(h.attackStrength, a.defenseStrength, 1.12), rnd);
    const ag = poisson(lam(a.attackStrength, h.defenseStrength, 0.92), rnd);
    result.set(h.id, applyScore(h, hg, ag));
    result.set(a.id, applyScore(a, ag, hg));
  }
  return teams.map(t => result.get(t.id) ?? t);
}

export const resetTables = (teams: Team[]): Team[] =>
  teams.map(t => ({ ...t, points: 0, played: 0, won: 0, drawn: 0, lost: 0, goalsFor: 0, goalsAgainst: 0 }));

/* ------------------------------------- STJD ------------------------------------------ */

export type ReportDetail = 'DETAILED' | 'OBJECTIVE' | 'VAGUE';

export interface StjdCase {
  id: string;
  teamId: string;
  teamName: string;
  label: string;
  reason: string;
  minute: number;
  kind: 'PLAYER' | 'MANAGER';
  redWasCorrect: boolean;
  baseGames: number;
}
export interface StjdRuling {
  caseId: string;
  annulled: boolean;
  games: number;
  reputationDelta: number;
  summary: string;
}
export interface Suspension {
  id: string;
  teamId: string;
  teamName: string;
  label: string;
  gamesLeft: number;
  reason: string;
}

export function buildStjdCases(
  report: MatchReport,
  home: Team,
  away: Team,
  decisions: { incident: { title: string }; isCorrect: boolean }[]
): StjdCase[] {
  return report.cards
    .filter(c => c.cardType === 'RED')
    .map((c, i) => {
      const team = c.team === 'HOME' ? home : away;
      const d = decisions.find(x => x.incident.title === c.reason);
      const manager = c.targetType === 'MANAGER';
      return {
        id: `${report.id}-${i}`,
        teamId: team.id,
        teamName: team.name,
        label: c.targetLabel,
        reason: c.reason,
        minute: c.minute,
        kind: manager ? 'MANAGER' : 'PLAYER',
        redWasCorrect: d ? d.isCorrect : true,
        baseGames: manager ? 1 : /violent|força|entrada/i.test(c.reason) ? 3 : 1
      } as StjdCase;
    });
}

/** A qualidade da súmula do árbitro pesa na chance de o tribunal anular a punição. */
export function judgeCase(c: StjdCase, detail: ReportDetail, rnd = Math.random): StjdRuling {
  const base = c.redWasCorrect ? 0.05 : 0.7;
  const adj = detail === 'VAGUE' ? 0.3 : detail === 'DETAILED' ? -0.05 : 0;
  const annulled = rnd() < clamp(base + adj, 0, 0.95);
  const games = annulled ? 0 : c.baseGames;
  return {
    caseId: c.id,
    annulled,
    games,
    reputationDelta: annulled ? -4 : c.redWasCorrect ? 2 : 0,
    summary: annulled
      ? `STJD anulou a expulsão de ${c.label} (${c.teamName}). A súmula não sustentou a decisão.`
      : `STJD manteve a expulsão de ${c.label} (${c.teamName}): ${games} jogo(s) de suspensão.`
  };
}

export const suspendedFor = (list: Suspension[], teamId: string) => list.filter(s => s.teamId === teamId && s.gamesLeft > 0);

export function addSuspension(list: Suspension[], c: StjdCase, r: StjdRuling): Suspension[] {
  if (r.annulled || r.games <= 0 || c.kind === 'MANAGER') return list;
  return [...list, { id: c.id, teamId: c.teamId, teamName: c.teamName, label: c.label, gamesLeft: r.games, reason: c.reason }];
}

/** Chame após cada partida com os ids dos dois times que jogaram. */
export const tickSuspensions = (list: Suspension[], playedTeamIds: string[]) =>
  list
    .map(s => (playedTeamIds.includes(s.teamId) ? { ...s, gamesLeft: s.gamesLeft - 1 } : s))
    .filter(s => s.gamesLeft > 0);

/** Time desfalcado joga pior (aplique ao montar a partida). */
export const teamWithAbsences = (t: Team, absences: number): Team =>
  absences <= 0 ? t : { ...t, attackStrength: t.attackStrength - 2 * absences, defenseStrength: t.defenseStrength - 1.5 * absences };

/* ------------------------------ pressão / mobbing ------------------------------------ */

type Mind = Pick<RefereeAttributes, 'authority' | 'stressResistance'>;

export function pressureAfterCall(level: number, o: { correct: boolean; severe: boolean; againstHome: boolean }): number {
  const delta = (o.correct ? -4 : 14) + (o.severe ? 8 : 0) + (o.againstHome ? 5 : 0);
  return clamp(level + delta, 0, 100);
}

/** Probabilidade de os jogadores cercarem o árbitro após uma decisão polêmica. */
export function mobbingChance(level: number, m: Mind): number {
  const base = Math.max(0, (level - 55) / 45) * 0.35;
  return clamp(base * (1.25 - m.authority / 160 - m.stressResistance / 320), 0, 0.5);
}
export const shouldMobbing = (level: number, m: Mind, rnd = Math.random) => rnd() < mobbingChance(level, m);

export type MobbingResponse = 'CALM_CAPTAIN' | 'HOLD_GROUND' | 'CARD_LEADER' | 'STOP_MATCH';
export interface MobbingOutcome {
  rating: number;
  pressure: number;
  stress: number; // dano na resistência ao estresse (positivo = piora)
  card: boolean;
  text: string;
}

const MOBBING_TABLE: Record<MobbingResponse, { win: [number, number, number]; lose: [number, number, number]; card: boolean; text: [string, string] }> = {
  CALM_CAPTAIN: { win: [0.1, -18, 0], lose: [-0.1, 4, 1], card: false, text: ['O capitão acalmou o grupo.', 'O capitão não conseguiu conter os colegas.'] },
  HOLD_GROUND: { win: [0.05, -8, 0], lose: [-0.2, 10, 2], card: false, text: ['Você manteve a postura e o grupo recuou.', 'Os jogadores insistiram e a pressão subiu.'] },
  CARD_LEADER: { win: [0.1, -22, 0], lose: [-0.3, 6, 1], card: true, text: ['Cartão ao líder: o grupo se dispersou.', 'Cartão questionado: a arquibancada reagiu mal.'] },
  STOP_MATCH: { win: [-0.15, -30, -1], lose: [-0.15, -30, -1], card: false, text: ['Jogo paralisado até a segurança restabelecer a ordem.', 'Jogo paralisado até a segurança restabelecer a ordem.'] }
};

export function resolveMobbing(r: MobbingResponse, m: Mind, rnd = Math.random): MobbingOutcome {
  const t = MOBBING_TABLE[r];
  const win = rnd() * 100 < m.authority * 0.6 + m.stressResistance * 0.4;
  const [rating, pressure, stress] = win ? t.win : t.lose;
  return { rating, pressure, stress, card: t.card, text: win ? t.text[0] : t.text[1] };
}

/* ------------------------------ economia / desgaste / cursos ------------------------- */

export interface Course {
  id: string;
  name: string;
  cost: number;
  weeks: number; // pontos de ação consumidos
  gain: Partial<RefereeAttributes>;
  minTier?: DivisionTier;
}

export const COURSES: Course[] = [
  { id: 'FIFA_LAWS', name: 'Leis do Jogo (IFAB): atualização', cost: 1800, weeks: 1, gain: { ruleKnowledge: 5 } },
  { id: 'FITNESS', name: 'Preparação física (teste FIFA)', cost: 1200, weeks: 1, gain: { physicalCondition: 4 } },
  { id: 'CONFLICT', name: 'Gestão de conflitos e comunicação', cost: 2200, weeks: 2, gain: { authority: 4, stressResistance: 3 } },
  { id: 'VAR_ACADEMY', name: 'Protocolo VAR/AVAR', cost: 3500, weeks: 2, gain: { ruleKnowledge: 6 }, minTier: 'SERIE_B' }
];

export function enrollCourse(
  bank: number,
  attrs: RefereeAttributes,
  done: string[],
  actionPoints: number,
  id: string,
  tier: DivisionTier
): { ok: boolean; reason?: string; bank: number; attrs: RefereeAttributes; done: string[]; actionPoints: number } {
  const c = COURSES.find(x => x.id === id);
  const fail = (reason: string) => ({ ok: false, reason, bank, attrs, done, actionPoints });
  if (!c) return fail('Curso inexistente.');
  if (done.includes(id)) return fail('Curso já concluído.');
  if (c.minTier && PLAYABLE_TIERS.indexOf(tier) < PLAYABLE_TIERS.indexOf(c.minTier)) return fail('Disponível só em divisões superiores.');
  if (bank < c.cost) return fail('Saldo insuficiente.');
  if (actionPoints < c.weeks) return fail('Pontos de ação insuficientes.');
  const next = { ...attrs };
  (Object.keys(c.gain) as (keyof RefereeAttributes)[]).forEach(k => {
    next[k] = clamp(next[k] + (c.gain[k] ?? 0), 0, 100);
  });
  return { ok: true, bank: bank - c.cost, attrs: next, done: [...done, id], actionPoints: actionPoints - c.weeks };
}

/** Desgaste acumulado (0..100) entre rodadas. */
export const fatigueAfterMatch = (f: number, distanceKm: number) => clamp(f + 8 + distanceKm * 0.9, 0, 100);
export const fatigueAfterAction = (f: number, kind: 'REST' | 'TRAIN') => clamp(f - (kind === 'REST' ? 18 : 6), 0, 100);
/** Condição física efetiva: cansaço corta até 40% da base. */
export const effectivePhysical = (physical: number, fatigue: number) => Math.round(physical * (1 - fatigue / 250));
