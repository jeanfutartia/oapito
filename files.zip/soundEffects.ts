/**
 * Motor de áudio 100% Web Audio API (zero assets). Mantém a API antiga
 * (playWhistle / playRadioBeep) e adiciona ambiente de estádio, filtro do fone do VAR,
 * spray e clique tático.
 *
 * Fidelidade: o apito é síntese por ouvido (3 "câmaras" levemente desafinadas -> batimento,
 * modulação FM, sopro filtrado), não uma réplica medida de um Fox 40. Para o som real,
 * coloque um sample CC0 em /public/audio/whistle.ogg e chame soundEffects.loadSample().
 */
type WhistleKind = 'SHORT' | 'LONG' | 'TRIPLE';

class AudioEngine {
  private ctx: AudioContext | null = null;
  private master!: GainNode;
  private sfx!: GainNode;
  private crowdBus!: GainNode;
  private crowdLP!: BiquadFilterNode;
  private baseGain: GainNode | null = null;
  private roarGain: GainNode | null = null;
  private roarBP: BiquadFilterNode | null = null;
  private booGain: GainNode | null = null;
  private hissGain: GainNode | null = null;
  private stopAmbienceFns: (() => void)[] = [];
  private samples = new Map<string, AudioBuffer>();
  private pink: AudioBuffer | null = null;
  private white: AudioBuffer | null = null;
  private muted = false;
  private volume = 0.8;

  /* ------------------------------- infraestrutura ------------------------------ */

  private ensure(): AudioContext | null {
    try {
      if (!this.ctx) {
        const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        const c = new AC();
        this.ctx = c;
        this.master = c.createGain();
        this.master.gain.value = this.muted ? 0 : this.volume;
        const lim = c.createDynamicsCompressor(); // limitador: evita clipar com apito + torcida
        lim.threshold.value = -8;
        lim.knee.value = 6;
        lim.ratio.value = 12;
        lim.attack.value = 0.003;
        lim.release.value = 0.15;
        this.master.connect(lim);
        lim.connect(c.destination);
        this.sfx = c.createGain();
        this.sfx.gain.value = 0.5;
        this.sfx.connect(this.master);
        this.crowdLP = c.createBiquadFilter();
        this.crowdLP.type = 'lowpass';
        this.crowdLP.frequency.value = 16000;
        this.crowdBus = c.createGain();
        this.crowdBus.connect(this.crowdLP);
        this.crowdLP.connect(this.master);
      }
      if (this.ctx.state === 'suspended') void this.ctx.resume();
      return this.ctx;
    } catch {
      return null; // navegador sem áudio: o jogo segue mudo
    }
  }

  /** Chame no primeiro clique do usuário (autoplay policy). */
  unlock() {
    this.ensure();
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.ctx) this.master.gain.setTargetAtTime(m ? 0 : this.volume, this.ctx.currentTime, 0.03);
  }

  setVolume(v: number) {
    this.volume = Math.min(1, Math.max(0, v));
    if (this.ctx && !this.muted) this.master.gain.setTargetAtTime(this.volume, this.ctx.currentTime, 0.03);
  }

  async loadSample(name: 'whistle', url: string) {
    const c = this.ensure();
    if (!c) return;
    try {
      const r = await fetch(url);
      if (!r.ok) return;
      this.samples.set(name, await c.decodeAudioData(await r.arrayBuffer()));
    } catch {
      /* mantém a síntese */
    }
  }

  private pinkBuf(c: AudioContext) {
    if (this.pink) return this.pink;
    const buf = c.createBuffer(1, c.sampleRate * 6, c.sampleRate);
    const d = buf.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (let i = 0; i < d.length; i++) {
      const w = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + w * 0.0555179;
      b1 = 0.99332 * b1 + w * 0.0750759;
      b2 = 0.969 * b2 + w * 0.153852;
      b3 = 0.8665 * b3 + w * 0.3104856;
      b4 = 0.55 * b4 + w * 0.5329522;
      b5 = -0.7616 * b5 - w * 0.016898;
      d[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + w * 0.5362) * 0.11;
      b6 = w * 0.115926;
    }
    return (this.pink = buf);
  }

  private whiteBuf(c: AudioContext) {
    if (this.white) return this.white;
    const buf = c.createBuffer(1, c.sampleRate, c.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    return (this.white = buf);
  }

  /* --------------------------------- apito (FM) -------------------------------- */

  playWhistle(kind: WhistleKind = 'SHORT') {
    const c = this.ensure();
    if (!c) return;
    const t0 = c.currentTime + 0.01;
    const pattern: Record<WhistleKind, [number, number][]> = {
      SHORT: [[0, 0.28]],
      LONG: [[0, 0.9]],
      TRIPLE: [[0, 0.28], [0.4, 0.28], [0.8, 0.8]]
    };
    pattern[kind].forEach(([offset, dur]) => this.blow(c, t0 + offset, dur));
  }

  private blow(c: AudioContext, t: number, d: number) {
    const sample = this.samples.get('whistle');
    if (sample) {
      const s = c.createBufferSource();
      const g = c.createGain();
      s.buffer = sample;
      g.gain.setValueAtTime(0.8, t);
      g.gain.setTargetAtTime(0, t + d, 0.02);
      s.connect(g);
      g.connect(this.sfx);
      s.start(t);
      s.stop(t + d + 0.15);
      return;
    }

    const f0 = 3650 + Math.random() * 60; // pequena variação entre apitos
    const out = c.createGain();
    out.gain.setValueAtTime(0.0001, t);
    out.gain.linearRampToValueAtTime(0.9, t + 0.012); // ataque do sopro
    out.gain.setValueAtTime(0.9, t + d - 0.04);
    out.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.03);

    const hp = c.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.value = 1800;
    const bp = c.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = f0 * 1.05;
    bp.Q.value = 2.2;
    bp.connect(hp);
    hp.connect(out);
    out.connect(this.sfx);

    // três câmaras próximas -> batimento (rugosidade típica de apito sem bolinha)
    const tones: [number, number][] = [[f0, 0.55], [f0 + 23, 0.45], [f0 * 1.26, 0.18]];
    tones.forEach(([f, amp]) => {
      const car = c.createOscillator();
      car.type = 'sine';
      car.frequency.setValueAtTime(f * 1.03, t); // sopro entra ~3% sharp
      car.frequency.exponentialRampToValueAtTime(f, t + 0.04);
      car.frequency.setValueAtTime(f, t + d - 0.06);
      car.frequency.exponentialRampToValueAtTime(f * 0.98, t + d); // cai ao soltar o ar

      const mod = c.createOscillator(); // FM: gera bandas laterais
      mod.frequency.value = f * 0.5;
      const modDepth = c.createGain();
      modDepth.gain.value = f * 0.06;
      mod.connect(modDepth);
      modDepth.connect(car.frequency);

      const vib = c.createOscillator(); // turbulência do ar
      vib.frequency.value = 5 + Math.random() * 2;
      const vibDepth = c.createGain();
      vibDepth.gain.value = 14;
      vib.connect(vibDepth);
      vibDepth.connect(car.frequency);

      const g = c.createGain();
      g.gain.value = amp;
      car.connect(g);
      g.connect(bp);
      [car, mod, vib].forEach(o => {
        o.start(t);
        o.stop(t + d + 0.1);
      });
    });

    // ruído de sopro em torno do tom
    const n = c.createBufferSource();
    n.buffer = this.whiteBuf(c);
    n.loop = true;
    const nbp = c.createBiquadFilter();
    nbp.type = 'bandpass';
    nbp.frequency.value = f0;
    nbp.Q.value = 5;
    const ng = c.createGain();
    ng.gain.value = 0.22;
    n.connect(nbp);
    nbp.connect(ng);
    ng.connect(bp);
    n.start(t);
    n.stop(t + d + 0.1);
  }

  /* ------------------------------ estádio / torcida ------------------------------ */

  startAmbience() {
    const c = this.ensure();
    if (!c || this.baseGain) return;
    const src = c.createBufferSource();
    src.buffer = this.pinkBuf(c);
    src.loop = true;

    // murmúrio constante
    const hp = c.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.value = 140;
    const bp = c.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 620;
    bp.Q.value = 0.6;
    this.baseGain = c.createGain();
    this.baseGain.gain.value = 0.05;
    src.connect(hp);
    hp.connect(bp);
    bp.connect(this.baseGain);
    this.baseGain.connect(this.crowdBus);
    const lfo = c.createOscillator(); // ondulação lenta
    lfo.frequency.value = 0.17;
    const lfoDepth = c.createGain();
    lfoDepth.gain.value = 0.012;
    lfo.connect(lfoDepth);
    lfoDepth.connect(this.baseGain.gain);
    lfo.start();

    // canal de explosão (gols)
    this.roarBP = c.createBiquadFilter();
    this.roarBP.type = 'bandpass';
    this.roarBP.frequency.value = 900;
    this.roarBP.Q.value = 0.5;
    this.roarGain = c.createGain();
    this.roarGain.gain.value = 0;
    src.connect(this.roarBP);
    this.roarBP.connect(this.roarGain);
    this.roarGain.connect(this.crowdBus);

    // canal de vaia (grave, com tremolo)
    const bbp = c.createBiquadFilter();
    bbp.type = 'bandpass';
    bbp.frequency.value = 280;
    bbp.Q.value = 1.1;
    this.booGain = c.createGain();
    this.booGain.gain.value = 0;
    const trem = c.createGain();
    trem.gain.value = 0.8;
    const tremLfo = c.createOscillator();
    tremLfo.frequency.value = 5.5;
    const tremDepth = c.createGain();
    tremDepth.gain.value = 0.2;
    tremLfo.connect(tremDepth);
    tremDepth.connect(trem.gain);
    tremLfo.start();
    src.connect(bbp);
    bbp.connect(this.booGain);
    this.booGain.connect(trem);
    trem.connect(this.crowdBus);

    src.start();
    this.stopAmbienceFns = [() => src.stop(), () => lfo.stop(), () => tremLfo.stop()];
  }

  stopAmbience() {
    this.stopAmbienceFns.forEach(fn => {
      try {
        fn();
      } catch {
        /* já parado */
      }
    });
    this.stopAmbienceFns = [];
    this.baseGain = this.roarGain = this.roarBP = this.booGain = null;
  }

  /** 0..1 (ex.: matchTemperature / 100). */
  setCrowdIntensity(i: number) {
    if (!this.ctx || !this.baseGain) return;
    const v = 0.035 + 0.14 * Math.min(1, Math.max(0, i));
    this.baseGain.gain.setTargetAtTime(v, this.ctx.currentTime, 0.6);
  }

  goalRoar() {
    if (!this.ctx || !this.roarGain || !this.roarBP) return;
    const t = this.ctx.currentTime;
    const g = this.roarGain.gain;
    g.cancelScheduledValues(t);
    g.setValueAtTime(g.value, t);
    g.linearRampToValueAtTime(0.55, t + 0.4);
    g.linearRampToValueAtTime(0.55, t + 2.2);
    g.exponentialRampToValueAtTime(0.0001, t + 6);
    g.setValueAtTime(0, t + 6.05);
    const f = this.roarBP.frequency;
    f.cancelScheduledValues(t);
    f.setValueAtTime(700, t);
    f.linearRampToValueAtTime(1300, t + 0.6);
    f.linearRampToValueAtTime(800, t + 5);
  }

  boo() {
    if (!this.ctx || !this.booGain) return;
    const t = this.ctx.currentTime;
    const g = this.booGain.gain;
    g.cancelScheduledValues(t);
    g.setValueAtTime(g.value, t);
    g.linearRampToValueAtTime(0.4, t + 0.5);
    g.linearRampToValueAtTime(0.4, t + 3);
    g.exponentialRampToValueAtTime(0.0001, t + 5.5);
    g.setValueAtTime(0, t + 5.55);
  }

  /** Fone do VAR: abafa o estádio (passa-baixa) e liga um chiado de rádio. */
  setHeadset(on: boolean) {
    const c = this.ensure();
    if (!c) return;
    const t = c.currentTime;
    this.crowdLP.frequency.setTargetAtTime(on ? 600 : 16000, t, 0.08);
    this.crowdBus.gain.setTargetAtTime(on ? 0.4 : 1, t, 0.1);
    if (!this.hissGain) {
      const n = c.createBufferSource();
      n.buffer = this.whiteBuf(c);
      n.loop = true;
      const bp = c.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.value = 2500;
      bp.Q.value = 1;
      this.hissGain = c.createGain();
      this.hissGain.gain.value = 0;
      n.connect(bp);
      bp.connect(this.hissGain);
      this.hissGain.connect(this.sfx);
      n.start();
    }
    this.hissGain.gain.setTargetAtTime(on ? 0.012 : 0, t, 0.1);
  }

  /* ------------------------------ efeitos pontuais ------------------------------ */

  playRadioBeep() {
    const c = this.ensure();
    if (!c) return;
    const t = c.currentTime;
    [[1200, 0], [900, 0.12]].forEach(([f, o]) => {
      const osc = c.createOscillator();
      const g = c.createGain();
      osc.type = 'sine';
      osc.frequency.value = f;
      g.gain.setValueAtTime(0.0001, t + o);
      g.gain.exponentialRampToValueAtTime(0.25, t + o + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, t + o + 0.09);
      osc.connect(g);
      g.connect(this.sfx);
      osc.start(t + o);
      osc.stop(t + o + 0.1);
    });
  }

  /** Spray de barreira: sopro agudo com varredura de filtro + estalo da válvula. */
  playSpray() {
    const c = this.ensure();
    if (!c) return;
    const t = c.currentTime;
    const src = c.createBufferSource();
    src.buffer = this.whiteBuf(c);
    src.loop = true;
    const hp = c.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.value = 2200;
    const bp = c.createBiquadFilter();
    bp.type = 'bandpass';
    bp.Q.value = 0.8;
    bp.frequency.setValueAtTime(5200, t);
    bp.frequency.linearRampToValueAtTime(3200, t + 1);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.5, t + 0.03);
    g.gain.setValueAtTime(0.5, t + 0.85);
    g.gain.linearRampToValueAtTime(0, t + 1.05);
    src.connect(hp);
    hp.connect(bp);
    bp.connect(g);
    g.connect(this.sfx);
    src.start(t);
    src.stop(t + 1.1);
    this.playClick();
  }

  /** Clique seco (cronômetro/botão tático). */
  playClick() {
    const c = this.ensure();
    if (!c) return;
    const t = c.currentTime;
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = 'square';
    o.frequency.setValueAtTime(1800, t);
    o.frequency.exponentialRampToValueAtTime(1100, t + 0.025);
    g.gain.setValueAtTime(0.18, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.03);
    o.connect(g);
    g.connect(this.sfx);
    o.start(t);
    o.stop(t + 0.04);
  }
}

export const soundEffects = new AudioEngine();
