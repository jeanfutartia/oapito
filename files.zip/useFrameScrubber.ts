import { useCallback, useEffect, useRef, useState } from 'react';

interface Options {
  max?: number;
  initial?: number;
  fps?: number; // taxa "do vídeo" a 1x
  enabled?: boolean; // atalhos de teclado ligados
}

/**
 * Substitui os setInterval(40ms) + frame decimal de IncidentFrameVisualizer/OffsideAnalysis.
 * - frames SEMPRE inteiros (o delta do impedimento não oscila por arredondamento);
 * - reprodução via requestAnimationFrame com acumulador (velocidade estável em qualquer monitor);
 * - atalhos: ← → (1 frame), Shift+← → (5 frames), Espaço (play/pause).
 */
export function useFrameScrubber({ max = 100, initial = 0, fps = 25, enabled = true }: Options = {}) {
  const [frame, setFrame] = useState(initial);
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(0.5);
  const frameRef = useRef(initial);

  const seek = useCallback(
    (n: number) => {
      const c = Math.min(max, Math.max(0, Math.round(n)));
      frameRef.current = c;
      setFrame(c);
    },
    [max]
  );

  const pause = useCallback(() => setPlaying(false), []);

  const step = useCallback(
    (d: number) => {
      setPlaying(false);
      seek(frameRef.current + d);
    },
    [seek]
  );

  const toggle = useCallback(() => {
    if (!playing && frameRef.current >= max) seek(0);
    setPlaying(p => !p);
  }, [playing, max, seek]);

  useEffect(() => {
    if (!playing) return;
    let last = performance.now();
    let acc = 0;
    let id = 0;
    const tick = (now: number) => {
      acc += ((now - last) / 1000) * fps * speed;
      last = now;
      const whole = Math.floor(acc);
      if (whole > 0) {
        acc -= whole;
        seek(frameRef.current + whole);
        if (frameRef.current >= max) {
          setPlaying(false);
          return;
        }
      }
      id = requestAnimationFrame(tick);
    };
    id = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(id);
  }, [playing, speed, fps, max, seek]);

  useEffect(() => {
    if (!enabled) return;
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) {
        if (!(t instanceof HTMLInputElement && t.type === 'range')) return;
      }
      if (e.key === 'ArrowLeft') { e.preventDefault(); step(e.shiftKey ? -5 : -1); }
      else if (e.key === 'ArrowRight') { e.preventDefault(); step(e.shiftKey ? 5 : 1); }
      else if (e.key === ' ') { e.preventDefault(); toggle(); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [enabled, step, toggle]);

  return { frame, playing, speed, setSpeed, seek, step, toggle, pause };
}
